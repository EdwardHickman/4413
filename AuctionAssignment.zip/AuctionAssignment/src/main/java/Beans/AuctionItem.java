package Beans;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import Beans.Time;

public class AuctionItem {
	
	int id;
	String name;
	String price;
	String auctionType;
	Time time;
	boolean selected;
	boolean bought;
	
	public AuctionItem(int id1, String name1, String price1, String auctionType1, String initTime1, boolean selected1) {
		id = id1;
		name = name1;
		price = price1;
		auctionType = auctionType1;
		
		if(auctionType.equals("Forward")) {
		int initTime = Integer.parseInt(initTime1);
		time = new Time(initTime);}
		time.setID(id);
		
		selected = selected1;
		
		
		
	}
	
	public int getID() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	
	public String getPrice() {
		return price;
	}
	
	public String getAuctionType() {
		return auctionType;
	}
	
	public String getTime() {
		return time.getTimeRemaining();
	}
	
	public boolean getSelected() {
		return selected;
	}
	
	public void setBought() {
		bought = true;
	}
	
	public boolean isBought() {
		return bought;
	}
	
}
