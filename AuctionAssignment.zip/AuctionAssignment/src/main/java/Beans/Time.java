package Beans;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Timer;
import java.util.TimerTask;

import servlets.AuctionListServlet;

public class Time {
	
	int initTime;
	int currentTime;
	
	Timer timer;
	
	boolean timeOver;
	
	int id;
	
	Connection conn = null;
	
	//testing
	/*public static void main(String[] args) {
		new Time(70);
	}*/
	
	// init = time in seconds to count down from
	public Time(int init) {
		initTime = init;
		
		timer = new Timer();
		currentTime = initTime;
		conn = AuctionListServlet.getDBConnection();
		
		
		timer.scheduleAtFixedRate(new TimerTask() {
			public void run() {
				/*setTime();
				System.out.println("Creating Statement Timer");
				try {
					PreparedStatement ps = conn.prepareStatement("UPDATE AuctionList SET RemainingTime = '" + getTimeRemaining() + "' WHERE ItemID = " + id +";");
				
					ps.executeUpdate();
	        	
					if(timeOver = true) {;
						ps.close();
						conn.close();
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}*/
	        	
	        	//getTimeRemaining();
				setTime();
				getTimeRemaining();
				//System.out.println(setTime());
				//System.out.println(getTimeRemaining());
			}
		}, 1000, 1000); // 1000 cause in milliseconds 1000 Ms = 1 sec (task,delay,period)
				
	}
	
	// count down
	private final int setTime() {
		if(currentTime == 1) {
			timer.cancel();
			timeOver = true;
		}
		return --currentTime;
	}
	
	
	public String getTimeRemaining() {
		if(currentTime > 60) {
			int minutes = currentTime/60;
			int seconds = currentTime%60;
			return Integer.toString(minutes) + "mins " + Integer.toString(seconds);}
		else
			return Integer.toString(currentTime) + "seconds";
	}
	
	public void setID(int id1) {
		id = id1;
	}
	
	

}
