package servlets;

import java.io.IOException;

import java.sql.*;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Beans.AuctionItem;

/**
 * Servlet implementation class AuctionListServlet
 */
@WebServlet("/AuctionListServlet")
public class AuctionListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	static Connection conn = null;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AuctionListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    public static Connection getDBConnection() {
    	return conn;
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String keyword = request.getParameter("keyword");
		
		HttpSession session = request.getSession();
        session.setAttribute("keyword",keyword);
        
        //Connection conn = null;
		String url = "jdbc:sqlite:C:\\Users\\jules\\OneDrive\\Desktop\\AuctionItem.db"; // :database location
		ArrayList<AuctionItem> items = new ArrayList<AuctionItem>();									// right click database and copy path (add extra \)
        
        try {       
        	Class.forName("org.sqlite.JDBC");
        	
        	conn = DriverManager.getConnection(url);		
        	System.out.println("Database Open");
        	
        	System.out.println("Creating Statement");
        	PreparedStatement ps = conn.prepareStatement("SELECT * FROM AuctionList WHERE ItemName LIKE '%" + keyword + "%'");
        	ResultSet rs = ps.executeQuery();
        	
        	
        	
        	
        	while(rs.next()) {
        		//items[itemCount] = new AuctionItem(rs.getInt("ItemID"), rs.getString("ItemName"),rs.getString("CurrentPrice"), rs.getString("AuctionType"), rs.getString("RemainingTime"), rs.getBoolean("Selected"));
        		AuctionItem currentItem = new AuctionItem(rs.getInt("ItemID"), rs.getString("ItemName"),rs.getString("CurrentPrice"), rs.getString("AuctionType"), rs.getString("RemainingTime"), rs.getBoolean("Selected"));
        		items.add(currentItem);
        		int kword = rs.getInt("ItemID");
        		String name = rs.getString("ItemName");
        		System.out.println("ID = " + kword + " Name = " + name);
        		
        		//PreparedStatement ps2 = conn.prepareStatement("UPDATE AuctionList SET RemainingTime = '" + currentItem.getTime() + "' WHERE ItemID = " + currentItem.getID() +";");
    			//ps2.executeUpdate();
        	}

        	rs.close();
			ps.close();
			
        	conn.close();
        
        
        }catch (Exception e) {
        	System.out.println("Exception Caught");
        	System.err.println(e.getMessage());
        }
        
        
        //maybe session.setAttribute("itemList", itemArray) array with all item id's including keyword 
        session.setAttribute("items", items);
        
        getServletConfig().getServletContext().getRequestDispatcher("/AuctionList.jsp").forward(request, response);
        
        
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
